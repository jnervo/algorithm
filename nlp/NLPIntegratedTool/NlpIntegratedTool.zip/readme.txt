﻿1. Please download ltp_data and put it in the same folder with NLPIntegratedTool.exe
https://github.com/HIT-SCIR/pyltp/tree/master/ltp_data

2. Once you got the hotel model, please put it at: .\Exe\NNCRFSegmentor\hotelmodel

3. If you want to modify the default case for "hotel", please modify the file: .\Exe\DefaultData\hotel.txt